import React from "react";

const ProductScreen = () => {
  return <div>Product</div>;
};

export default ProductScreen;
